import Link from "next/link";
import { themes, examFlow, faulkswagonCase } from "@/data/themes";
import { courseMeta } from "@/data/study";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function HomePage() {
  return (
    <div className="space-y-12">
      <section className="relative overflow-hidden rounded-2xl border border-border bg-[hsl(var(--ink))] px-6 py-10 text-[hsl(var(--paper))] sm:px-10 sm:py-14">
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "radial-gradient(circle at 20% 20%, hsl(199 70% 45% / 0.55), transparent 45%), radial-gradient(circle at 90% 10%, hsl(16 75% 50% / 0.35), transparent 35%), linear-gradient(135deg, transparent 40%, hsl(199 50% 20% / 0.5))",
          }}
        />
        <div className="relative max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[hsl(16_80%_72%)]">
            {courseMeta.code} · {courseMeta.term} · Mundtlig eksamen
          </p>
          <h1 className="font-display mt-3 text-4xl leading-[1.05] tracking-tight sm:text-5xl">
            12 temaer. Ét A4-ark. Fem minutter ved tavlen.
          </h1>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">
            Bygget efter underviserens vejledning: kapitler, 4xExplanation,
            Faulkswagen A3 og workshop-spor — plus ordbog, teori og tests.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild size="lg" className="bg-[hsl(var(--coral))] hover:bg-[hsl(16_72%_42%)]">
              <Link href="/eksamen">Eksamensoverblik</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
            >
              <Link href="/ordbog">Fagbegrebsordbog</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
            >
              <Link href="/sammenhaeng">Se sammenhænge</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
            >
              <Link href="/test">Test dig selv</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
            >
              <a href="/scm-eksamen.zip" download>
                Download hele projektet (.zip)
              </a>
            </Button>
          </div>
        </div>
      </section>

      <section>
        <div className="mb-4 flex items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl text-[hsl(var(--ink))]">
              Eksamensflow
            </h2>
            <p className="text-sm text-muted-foreground">
              20 minutter i alt — brug tiden præcist.
            </p>
          </div>
        </div>
        <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {examFlow.map((item, i) => (
            <li
              key={item.step}
              className="rounded-xl border border-border bg-card/80 p-4 shadow-sm"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[hsl(var(--sea))]">
                {item.step}
              </p>
              <p className="mt-2 text-sm leading-snug text-foreground/85">
                {item.detail}
              </p>
            </li>
          ))}
        </ol>
      </section>

      <section>
        <div className="mb-4">
          <h2 className="font-display text-2xl text-[hsl(var(--ink))]">
            De 12 temaer
          </h2>
          <p className="text-sm text-muted-foreground">
            Åbn et tema for A4-ark, formler og øvespørgsmål.
          </p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {themes.map((theme) => (
            <Link key={theme.id} href={`/tema/${theme.slug}`} className="group">
              <Card className="h-full transition duration-200 group-hover:-translate-y-0.5 group-hover:border-[hsl(var(--sea))] group-hover:shadow-md">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">Tema {theme.id}</Badge>
                    <span className="text-xs text-muted-foreground opacity-0 transition group-hover:opacity-100">
                      Åbn →
                    </span>
                  </div>
                  <CardTitle className="font-display text-lg leading-snug">
                    {theme.shortTitle}
                  </CardTitle>
                  <CardDescription className="line-clamp-2">
                    {theme.agenda[0].replace(/^\d+\.\s*/, "")} ·{" "}
                    {theme.agenda[1].replace(/^\d+\.\s*/, "")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-muted-foreground">
                    {theme.teacherAngles.length} lærer-vinkler ·{" "}
                    {theme.examAnswers.length} dialogspørgsmål
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-[hsl(var(--sea)/0.3)] bg-[hsl(199_40%_97%)] p-6 sm:p-8">
        <Badge variant="secondary">Medbring til eksamen</Badge>
        <h2 className="font-display mt-3 text-2xl text-[hsl(var(--ink))]">
          A4 + Faulkswagen A3 + din workshop
        </h2>
        <ul className="mt-3 grid gap-2 sm:grid-cols-3">
          {courseMeta.bringAlong.map((item) => (
            <li
              key={item}
              className="rounded-md bg-white/80 px-3 py-2 text-sm leading-snug text-foreground/85"
            >
              {item}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-muted-foreground">
          {courseMeta.generalAdvice[0]}
        </p>
      </section>

      <section className="rounded-2xl border border-dashed border-[hsl(var(--coral))]/50 bg-[hsl(16_60%_96%)] p-6 sm:p-8">
        <Badge className="bg-[hsl(var(--coral))]">Tværgående case</Badge>
        <h2 className="font-display mt-3 text-2xl text-[hsl(var(--ink))]">
          {faulkswagonCase.title}
        </h2>
        <p className="mt-2 max-w-2xl text-sm text-foreground/80">
          Tag dit eget A3-kort med. Casen bruges især under location, network
          design og transportation — og i dialogen på tværs af temaerne.
        </p>
        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
          {faulkswagonCase.agenda.map((a) => (
            <li
              key={a}
              className="rounded-md bg-white/70 px-3 py-2 text-sm font-medium"
            >
              {a}
            </li>
          ))}
        </ul>
        <Button asChild className="mt-5" variant="outline">
          <Link href="/tema/faulkswagon">Åbn Faulkswagon-ark</Link>
        </Button>
      </section>
    </div>
  );
}
